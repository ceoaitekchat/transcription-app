<template><div>Transcription App</div></template>
<script setup>
// Vue composition API setup
</script>